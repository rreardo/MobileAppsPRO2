import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text, View, TextInput, TouchableOpacity } from 'react-native';
import HomeScreen from './Screens/HomeScreen'; // Create ProfileScreen.js for user profile
import Settings from './Screens/Settings';
import Brightness from './Screens/Brightness.js';
import Textsize from './Screens/TextSize.js';
import styles from './styles';
import ContactUs from './Screens/Contact';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

export default function App() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

function handleLogin(navigation) {
  if (username === '123' && password === '123') {
    navigation.navigate('HomeTab');
  } else {
    alert('Invalid username or password. Please re-enter your correct username and password');
  }
}

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen
          name="Login"
          options={{
            headerShown: false,
          }}
        >
          {({ navigation }) => (
            <View style={styles.container}>
              <View style={styles.header}>
                <Text style={styles.title}>ROI</Text>
              </View>

              <Text style={styles.subheading}>Staff Directory</Text>
              <Text style={styles.subheading2}>Get Started!</Text>

              <TextInput
                style={styles.input}
                placeholder="Username"
                onChangeText={(username) => setUsername(username)}
              />

              <TextInput
                style={styles.input}
                placeholder="Password"
                onChangeText={(password) => setPassword(password)}
              />

              <TouchableOpacity
                style={styles.button}
                onPress={() => handleLogin(navigation)}
              >
                <Text style={styles.buttonTitle}>Login</Text>
              </TouchableOpacity>
              <Text style={styles.subheading3}>Don't have a login?</Text>
              <Text style={styles.subheading4}>Contact your administrator</Text>
            </View>
          )}
        </Stack.Screen>
        <Stack.Screen name="HomeTab"
        options={{
            headerShown: false,
          }}
           component={TabNavigator} />
           <Stack.Screen name="Brightness"
           component={Brightness} />
          <Stack.Screen name="Textsize" component={Textsize} />
          <Stack.Screen name="Contact" component={ContactUs} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

function TabNavigator() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Staff Directory"
      options={{
            headerShown: false,
          }}
           component={HomeScreen} />
           <Tab.Screen name="Settings"
           options={{
            headerShown: false,
          }}
           component={Settings} />
    </Tab.Navigator>
  );
}