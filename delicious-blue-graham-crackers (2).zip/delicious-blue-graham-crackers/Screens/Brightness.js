import React, { useEffect, useState } from 'react';
import { StyleSheet, View, Text, Button } from 'react-native';
import * as Brightness from 'expo-brightness';

export default function App() {
  const [brightness, setBrightness] = useState(0);

  useEffect(() => {
    (async () => {
      const { status } = await Brightness.requestPermissionsAsync();
      if (status === 'granted') {
        const currentBrightness = await Brightness.getSystemBrightnessAsync();
        setBrightness(currentBrightness);
      }
    })();
  }, []);

  const increaseBrightness = async () => {
    const newBrightness = Math.min(brightness + 0.1, 1);
    setBrightness(newBrightness);
    try {
      await Brightness.setSystemBrightnessAsync(newBrightness);
    } catch (error) {
      console.error('Error setting brightness:', error);
    }
  };

  const decreaseBrightness = async () => {
    const newBrightness = Math.max(brightness - 0.1, 0);
    setBrightness(newBrightness);
    try {
      await Brightness.setSystemBrightnessAsync(newBrightness);
    } catch (error) {
      console.error('Error setting brightness:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Brightness Adjustment</Text>
      <View style={styles.buttonContainer}>
        <Button title="Decrease" onPress={decreaseBrightness} color="#941a1d" />
        <Text style={styles.brightnessText}>Brightness: {brightness.toFixed(2)}</Text>
        <Button title="Increase" onPress={increaseBrightness} color="#941a1d" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  text: {
    fontSize: 20,
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  brightnessText: {
    marginHorizontal: 10,
    fontSize: 18,
  },
});