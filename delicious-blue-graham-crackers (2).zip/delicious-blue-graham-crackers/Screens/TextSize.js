import React, { useState } from 'react';
import { StyleSheet, View, Text, Button } from 'react-native';

export default function FontSizeAdjuster() {
  const [fontSize, setFontSize] = useState(20); // Initial font size

  const increaseFontSize = () => {
    setFontSize(fontSize + 2); // Increase font size by 2
  };

  const decreaseFontSize = () => {
    setFontSize(fontSize - 2); // Decrease font size by 2
  };

  return (
    <View style={styles.container}>
      <Text style={[styles.text, { fontSize }]}>Font Size Adjustment</Text>
      <View style={styles.buttonContainer}>
        <Button title="Decrease Font Size" onPress={decreaseFontSize} color="#941a1d" />
        <Text style={styles.fontSizeText}>Font Size: {fontSize}</Text>
        <Button title="Increase Font Size" onPress={increaseFontSize} color="#941a1d" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  text: {
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  fontSizeText: {
    marginHorizontal: 10,
    fontSize: 18,
  },
});