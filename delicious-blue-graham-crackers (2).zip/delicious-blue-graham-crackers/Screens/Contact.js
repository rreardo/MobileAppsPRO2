import React from 'react';
import { Text, View, StyleSheet } from 'react-native';

export default function ContactUs() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Contact Us</Text>
      <View style={styles.body}>
        <Text>
          Feel free to reach out to us at contact@roi.com for any inquiries or support.
        </Text>
        <Text>
          Our office hours are Monday to Friday, 9 AM - 5 PM (EST).
        </Text>
        <Text>
          Address: 55 Royal Lane, Sydney, Australia
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 15,
    paddingHorizontal: 40,
    backgroundColor: 'white'
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    marginLeft: -15,
  },
  body: {
    marginBottom: 20,
  },
});