import React, { useState, useRef } from 'react';
import { View, Text, FlatList, Image, StyleSheet, TouchableOpacity, Modal, TextInput } from 'react-native';


const initialStaffMembers = [
  {
    id: '1',
    name: 'John Smith',
    department: '1',
    number: '02 9988 2211',
    address: '1 Code Lane, Javaville',
    image: 'https://pbs.twimg.com/media/FjU2lkcWYAgNG6d.jpg', 
  },
{
    id: '2',
    name: 'Sue White',
    department: 'Marketing',
    number: '03 8899 2255',
    address: '16 Bit Way, Byte Cove',
    image: 'https://dl.memuplay.com/new_market/img/com.vicman.newprofilepic.icon.2022-06-07-21-33-07.png', 
  },
  {
    id: '3',
    name: 'Bob OBits',
    department: 'Marketing',
    number: '05 7788 2255',
    address: '8 Silicon Road, Cloud Hills',
    image: 'https://img.freepik.com/premium-photo/realistic-3d-cartoon-character-xu-glasses-brown-hair-beard_899449-58460.jpg?size=338&ext=jpg&ga=GA1.1.1826414947.1698883200&semt=ais', 
  },
  {
    id: '4',
    name: 'Mary Blue',
    department: 'Marketing',
    number: '06 4455 9988',
    address: '4 Processor Boulevard, Appletson',
    image: 'https://media.marketrealist.com/brand-img/Ik1D_rqGf/0x0/newprofile-pic-1-1652281674003.jpg',
  },
    {
    id: '5',
    name: 'Mick Green',
    department: 'Marketing',
    number: '02 9988 1122',
    address: '700 Bandwidth Street, Bufferland',
    image: 'https://community.upwork.com/bpyhf24739/attachments/bpyhf24739/New_to_Upwork/112350/1/Hostess%20characters.jpg',
  },
];

export default function HomeScreen() {
  const [staffMembers, setStaffMembers] = useState(initialStaffMembers);
  
  const renderStaff = ({ item }) => (
    <View style={styles.staffContainer}>
      <View style={styles.profile}>
        <Image source={{ uri: item.image }} style={styles.profileImage} />
        <View style={styles.profileDetails}>
          <Text style={styles.name}>{item.name}</Text>
          <Text>{item.department}</Text>
          <Text>{item.number}</Text>
          <Text>{item.address}</Text>
        </View>
        <TouchableOpacity onPress={() => handleDeleteStaff(item.id)}>
          <Text style={styles.deleteButton}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const handleDeleteStaff = (id) => {
    const updatedStaff = staffMembers.filter((member) => member.id !== id);
    setStaffMembers(updatedStaff);
  };

  const handleReAddStaff = () => {
    const reAddedStaffMember = initialStaffMembers.find((member) => !staffMembers.find((staff) => staff.id === member.id));
    if (reAddedStaffMember) {
      setStaffMembers([...staffMembers, reAddedStaffMember]);
    }
  };

   return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Staff Directory</Text>
      </View>
      <View style={styles.body}>
        <FlatList
          data={staffMembers}
          renderItem={renderStaff}
          keyExtractor={(item) => item.id}
        />
        <TouchableOpacity onPress={handleReAddStaff}>
          <Text style={styles.addButton}>Re-Add Staff</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white', 
  },
  header: {
    backgroundColor: '#941a1d', 
    paddingVertical: 20,
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    fontFamily: 'Trebuchet',
  },
  body: {
    paddingHorizontal: 20,
    paddingTop: 20,
    flex: 1,
  },
  staffContainer: {
    marginBottom: 20,
  },
  profile: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 10,
  },
  profileDetails: {
    justifyContent: 'center',
  },
  name: {
    fontWeight: 'bold',
    marginBottom: 5,
  },
  deleteButton: {
    color: 'red',
    marginLeft: 10,
  },
  addButton: {
    alignSelf: 'center',
    fontWeight: 'bold',
    marginTop: 20,
    color: 'red',
    fontFamily: 'Trebuchet',
  },
});