import React from 'react';
import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';

export default function Settings({ navigation }) {
  const goToBrightnessScreen = () => {
    navigation.navigate('Brightness');
  };

  const goToTextSizeScreen = () => {
    navigation.navigate('Textsize');
  };

  const Logout = () => {
    navigation.reset({
      index: 0,
      routes: [{ name: 'Login' }],
    });
  };

  const goToContactUs = () => {
    navigation.navigate('Contact');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Settings</Text>
      <TouchableOpacity onPress={goToBrightnessScreen}>
        <Text style={styles.button}>Go to Brightness</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={goToTextSizeScreen}>
        <Text style={styles.button}>Go to Text Size</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={goToContactUs}>
        <Text style={styles.contactButton}>Contact Us</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={Logout}>
        <Text style={styles.logoutButton}>Log Out</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 15,
    paddingHorizontal: 40,
    backgroundColor: 'white'
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    marginLeft: -15,
  },
  button: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#941a1d',
    color: '#ffffff',
    fontFamily: 'Trebuchet',
    textAlign: 'center',
    borderRadius: 5,
  },
  contactButton: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#941a1d',
    color: '#ffffff',
    fontFamily: 'Trebuchet',
    textAlign: 'center',
    borderRadius: 5,
  },
  logoutButton: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#941a1d',
    color: '#ffffff',
    fontFamily: 'Trebuchet',
    textAlign: 'center',
    borderRadius: 5,
  },
});