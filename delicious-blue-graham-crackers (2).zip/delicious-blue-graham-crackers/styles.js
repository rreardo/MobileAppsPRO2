import { StyleSheet } from 'react-native';

module.exports = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingTop: 50,
    paddingHorizontal: 20,
  },
  header: {
    backgroundColor: '#941a1d',
    paddingVertical: 20,
    paddingHorizontal: 30,
    borderWidth: 10,
    borderColor: '#262626',
    marginBottom: 30,
    borderRadius: 15,
  },
  title: {
    fontSize: 80,
    fontWeight: 'bold',
    color: '#FFFFFF',
    fontFamily: 'Trebuchet',
    marginTop: 10,
  },
  subheading: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000000',
    fontFamily: 'Trebuchet',
    marginTop: -20,
  },
  subheading2: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000000',
    fontFamily: 'Trebuchet',
    marginTop: 80,
  },
input: {
  backgroundColor: '#FFFFFF',
  color: '#000000',
  borderRadius: 15,
  borderWidth: 1,
  borderColor: '#000000', //
  margin: 15,
  padding: 15,
  fontSize: 18,
  fontFamily: 'Trebuchet',
  textAlign: 'center',
},
  button: {
    backgroundColor: '#941a1d',
    marginHorizontal: 20,
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  buttonTitle: {
    fontSize: 18,
    fontFamily: 'Trebuchet',
    color: '#FFFFFF',
    textAlign: 'center',
  },
      subheading3: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000000',
    fontFamily: 'Trebuchet',
    marginTop: 90,
  },
      subheading4: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#000000',
    fontFamily: 'Trebuchet',
    marginTop: 10,
      }
});